<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user_model extends CI_Model {

    public function loginCheck($username,$password)
    {
        $data = array(
            'username' => $username,
            'password' => $password
        );
        $this->db->where($data);
        return $this->db->get('user');
    }
    public function getAdmin($id)
    {
        $this->db->where('id_user', $id);
        return $this->db->get('admin');
    }
    public function getUser($id)
    {
        $this->db->where('id_user', $id);
        return $this->db->get('orang_tua');
    }
    public function register($data)
    {
        $this->db->insert('user', $data);
    }
    
    public function getIdUser($username)
    {
        $this->db->where('username',$username);
        return $this->db->get('user');
    }
    public function registerAdmin($data)
    {
        $this->db->insert('admin', $data);
    }
    public function registerUser($data)
    {
        $this->db->insert('orang_tua', $data);
    }

    public function registeraccoutuser($data)
    {
        $this->db->insert('user', $data);
    }
    public function registeraccoutAdmin($data)
    {
        $this->db->insert('user', $data);
    }

    public function success($msg)
    {
        return "
        <div class='well success'>
            ".$msg."
        </div>";
    }

    public function danger($msg)
    {
        return "
        <div class='well danger'>
        ".$msg."
        </div>";
    }

}