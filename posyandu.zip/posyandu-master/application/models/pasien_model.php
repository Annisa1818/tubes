<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class pasien_model extends CI_Model {

    public function jadwal()
    {
        return $this->db->get('jadwal');    
    }

}

/* End of file pasien_model.php */
