<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class admin_model extends CI_Model {

    public function getOrtu()
    {
        return $this->db->get('orang_tua');
    }

    public function getAnakOrtu($id)
    {
        $this->db->where('id_wali', $id);        
        return $this->db->get('balita'); 
    }
    public function tambahAnak($data)
    {
        $this->db->insert('balita', $data);
    }

    public function hapusAnak($id)
    {
        $this->db->where('id_balita', $id);
        $this->db->delete('balita');
    }

    public function getAnak($id)
    {
        $this->db->where('id_balita', $id);        
        return $this->db->get('balita'); 
    }

    public function editAnak($data,$where)
    {
        $this->db->where('id_balita', $where);
        
        $this->db->update('balita', $data);
    }

    public function getImunitation()
    {
        return $this->db->get('imunisasi');   
    }

    public function tambahImunisasi($data)
    {
        $this->db->insert('imunisasi', $data);
    }

    public function getidimunisasi($id)
    {
        $this->db->where('id_imunisasi', $id);
        return $this->db->get('imunisasi');   
    }

    public function editImunisasi($data,$where)
    {
        $this->db->where('id_imunisasi', $where);
        $this->db->update('imunisasi', $data);
    }

    public function hapusImunisasi($where)
    {
        $this->db->where('id_imunisasi', $where);        
        $this->db->delete('imunisasi');
    }

    public function getjadwalId($id)
    {
        $this->db->where('id', $id);
        return $this->db->get('jadwal');    
        
    }
    public function jadwal()
    {
        return $this->db->get('jadwal');    
    }

    public function tutupHari($id)
    {
        $this->db->where('id', $id);
        $this->db->update('jadwal', array('jam' => 0));
    }

    public function ubahJam($data,$where)
    {
        $this->db->where('id', $where);
        $this->db->update('jadwal', array('jam' => $data));
    }
}