<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {

    public function index()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/dashboard');
        $this->load->view('part/footercontent');
    }
    
    public function message()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/message');
        $this->load->view('part/footercontent');
    }
    public function profile()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/profile');
        $this->load->view('part/footercontent');
    }

    public function dataKader()
    {
        $data['ortu'] = $this->admin_model->getOrtu()->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/datakader',$data);
        $this->load->view('part/footercontent');
    }

    public function imunisasi()
    {
        $data['imunisasi'] = $this->admin_model->getImunitation()->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/imunisasi',$data);
        $this->load->view('part/footercontent');
    }

    public function jadwal()
    {
        $data['jadwal'] = $this->admin_model->jadwal()->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/jadwal',$data);
        $this->load->view('part/footercontent');
    }

    public function ubahJadwal($id)
    {
        $data['jadwal'] = $this->admin_model->getjadwalId($id)->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/jadwal/editjadwal',$data);
        $this->load->view('part/footercontent');
    }

    public function prosesUbahJadwal()
    {
        $jam = $this->input->post('jam1')." sampai ".$this->input->post('jam2');
        $id = $this->input->post('id');
        
        $this->admin_model->ubahJam($jam,$id);
        redirect('admin/jadwal');
    }

    public function tutupHari($id)
    {
        $this->admin_model->tutupHari($id);
        redirect('admin/jadwal');
    }

    public function imunisasiAnak()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/imunisasiAnak');
        $this->load->view('part/footercontent');
    }

    public function tambahAnak($id)
    {
        $data['id'] = $id;
        $data['ortu'] = $this->admin_model->getAnakOrtu($id)->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/form/tambahanak',$data);
        $this->load->view('part/footercontent');
    }

    public function prosesRegistrasiAnak()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('tgllahir', 'tgllahir', 'required');
        $this->form_validation->set_rules('umur', 'umur', 'required');
        
        if ($this->form_validation->run() == TRUE) {
            $data = array(
                'nama' => $this->input->post('nama'), 
                'tanggal_lahir' => $this->input->post('tgllahir'), 
                'umur' => $this->input->post('umur'), 
                'id_wali' => $this->input->post('idortu') 
            );
            $this->admin_model->tambahAnak($data);
            redirect('admin/datakader');
        } else {
            $this->session->flashdata('name');
            $id = $this->input->post('idortu');
            $url = 'admin/tambahAnak/'.$id;
            redirect($url);
        }
    }

    public function hapusAnak($idortu,$idbalita)
    {
        $this->admin_model->hapusAnak($idbalita);
        
        $url = 'admin/tambahAnak/'.$idortu;
        redirect($url);
    }

    public function editAnak($idortu,$idbalita)
    {
        $data['anak'] = $this->admin_model->getAnak($idbalita)->result();
        $data['ortu'] = $idortu;
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/form/editanak',$data);
        $this->load->view('part/footercontent');
    }

    public function prosesEditAnak()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('tgllahir', 'tgllahir', 'required');
        $this->form_validation->set_rules('umur', 'umur', 'required');
        
        if ($this->form_validation->run() == TRUE) {
           $where = $this->input->post('idanak');
           
            $data = array(
                'nama' => $this->input->post('nama'), 
                'tanggal_lahir' => $this->input->post('tgllahir'), 
                'umur' => $this->input->post('umur')
            );
            $this->admin_model->editAnak($data,$where);
            redirect('admin/datakader');
        } else {
            $this->session->flashdata('name');
            $idortu = $this->input->post('idortu');
            $idbalita = $this->input->post('idortu');
            $url = 'admin/editAnak/'.$idortu."/".$idbalita;
            redirect($url);
        }
    }

    public function tambahImunisasi()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/imunisasi/tambahimunisasi');
        $this->load->view('part/footercontent');
    }

    public function prosesTambahImunisasi()
    {
        $data = array(
            'nama_imunisasi' => $this->input->post('nama'),
            'tanggal_imunisasi' => $this->input->post('tglimunisasi')  
        );
        $this->admin_model->tambahImunisasi($data);
        redirect('admin/imunisasi');
        
    }

    public function editImunisasi($id)
    {
        $data['imunisasi'] = $this->admin_model->getidimunisasi($id)->result();
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaradmin');
        $this->load->view('admin/imunisasi/editimunisasi',$data);
        $this->load->view('part/footercontent');
    }
    public function prosesEditImunisasi()
    {
        $data = array(
            'nama_imunisasi' => $this->input->post('nama'),
            'tanggal_imunisasi' => $this->input->post('tglimunisasi')  
        );
        $where = $this->input->post('id');

        $this->admin_model->editImunisasi($data,$where);
        redirect('admin/imunisasi');
    
    }
    
    public function hapusImunisasi($id)
    {
        $this->admin_model->hapusImunisasi($id);
        redirect('admin/imunisasi');
    }
}