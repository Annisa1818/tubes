<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class user extends CI_Controller {

    public function index()
    {
        $this->load->view('part/headerauth');
        $this->load->view('auth/login');
        $this->load->view('part/footerauth');  
    }

    public function registerAdmin()
    {
        $this->load->view('part/headerauth');
        $this->load->view('auth/registerAdmin');
        $this->load->view('part/footerauth');
    }
    public function register()
    {
        $this->load->view('part/headerauth');
        $this->load->view('auth/register');
        $this->load->view('part/footerauth');  
    }
    
    public function adminRegisterProses()
    {
       $this->form_validation->set_rules('username', 'username', 'required');
       $this->form_validation->set_rules('password', 'password', 'required');
       $this->form_validation->set_rules('passwordconfirm', 'passwordconfirm', 'required');
       $this->form_validation->set_rules('alamat', 'alamat', 'required');
       $this->form_validation->set_rules('nama', 'nama', 'required');
       
       if ($this->form_validation->run() == TRUE) {
           $username = $this->input->post('username');
           $alamat = $this->input->post('alamat');
           $passwordconfirm = md5($this->input->post('passwordconfirm'));
           $password = md5($this->input->post('password'));
           $nama = $this->input->post('nama');

           if($password == $passwordconfirm){
               $data = array(
                   'username' => $username, 
                   'password' => $password, 
                   'is_admin' => 1
                );
                $this->user_model->registeraccoutAdmin($data);
                $admin = $this->user_model->getIdUser($username)->result();
                
                $data = array(
                   'alamat' => $alamat, 
                   'nama' => $nama,
                   'id_user' => $admin[0]->id_user
                );
                $this->user_model->registerAdmin($data);
                $this->session->set_flashdata('alert', $this->user_model->success("registrasi success"));
                redirect('user');
           }else{
            $this->session->set_flashdata('alert', $this->user_model->danger("password dan hint password harus sama"));
            redirect('user/registerAdmin');
           }
        } else {
            $this->session->set_flashdata('alert', $this->user_model->danger("lengkapi form registrasi"));
            redirect('user/registerAdmin');
        }
       
    }
    
    public function userRegisterProses()
    {
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_rules('passwordconfirm', 'passwordconfirm', 'required');       
        $this->form_validation->set_rules('namaayah', 'namaayah', 'required');       
        $this->form_validation->set_rules('namaibu', 'namaibu', 'required');       
        $this->form_validation->set_rules('alamat', 'alamat', 'required');       
       if ($this->form_validation->run() == TRUE) {
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            $passwordconfirm = md5($this->input->post('passwordconfirm'));
            $namaayah = $this->input->post('namaayah');
            $namaibu = $this->input->post('namaibu');
            $alamat = $this->input->post('alamat');

            if($password == $passwordconfirm){
                $datareg = array(
                    'username' => $username, 
                    'password' => $password, 
                    'is_admin' => 0 
                );
                $this->user_model->registeraccoutuser($datareg);
                $user = $this->user_model->getIdUser($username)->result();
                
                $data = array(
                    'alamat' => $alamat, 
                    'nama_ibu' => $namaibu,
                    'nama_ayah' => $namaayah,
                    'id_user' => $user[0]->id_user
                );
                $this->user_model->registerUser($data);
                $this->session->set_flashdata('alert', $this->user_model->success("registrasi success"));
                redirect('user');   
            }else{
                $this->session->set_flashdata('alert', $this->user_model->danger("password dan hint password harus sama"));
                redirect('user/register');
            }
        } else {
            $this->session->set_flashdata('alert', $this->user_model->danger("lengkapi form registrasi"));
            redirect('user/register');
        }
       
    }

    public function loginProses()
    {
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        
        if ($this->form_validation->run() == TRUE) {
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            $auth = $this->user_model->loginCheck($username,$password)->result();
            if (!empty($auth)) {
                if ($auth[0]->is_admin == 1) {
                    $auth = $this->user_model->getAdmin($auth[0]->id_user)->result();
                    
                    $array = array(
                        'id' => $auth[0]->id_admin,
                        'nama' => $auth[0]->nama,
                        'id' => $auth[0]->id_admin,
                        'alamat' => $auth[0]->alamat
                    );
                    
                    $this->session->set_userdata( $array );
                    
                    redirect('admin');
                    
                }else{
                    $auth = $this->user_model->getUser($auth[0]->id_user)->result();
                    
                    $array = array(
                        'id' => $auth[0]->id_wali,
                        'nama' => $auth[0]->nama_ibu,
                        'alamat' => $auth[0]->alamat,
                    );
                    $this->session->set_userdata($array);
                    
                    redirect('pasien');
                }
            } else {
                $this->session->set_flashdata('alert', $this->user_model->danger("password atau username anda salah"));
                redirect('user');
            }
        
            
        } else {
            $this->session->set_flashdata('alert', $this->user_model->danger("isilah username dan password anda"));
            redirect('user');
        }
        
    }

    // ini logout
    public function logout()
    {   
       $this->session->sess_destroy();
       redirect('user');
    }

}

?>