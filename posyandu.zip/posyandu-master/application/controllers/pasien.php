<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class pasien extends CI_Controller {

    public function index()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaruser');
        $this->load->view('user/dashboard');
        $this->load->view('part/footercontent');
    }

    public function message()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaruser');
        $this->load->view('user/dashboard');
        $this->load->view('part/footercontent');   
    }

    public function petunjukpuskesmas()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaruser');
        $this->load->view('user/dashboard');
        $this->load->view('part/footercontent');
    }

    public function jadwalPuskesmas()
    {
        $data['jadwal'] = $this->pasien_model->jadwal()->result();

        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaruser');
        $this->load->view('user/jadwal',$data);
        $this->load->view('part/footercontent');
    }

    public function pengumumanImunisasi()
    {
        $this->load->view('part/headaercontent');
        $this->load->view('part/sidebaruser');
        $this->load->view('user/dashboard');
        $this->load->view('part/footercontent');
    }

}