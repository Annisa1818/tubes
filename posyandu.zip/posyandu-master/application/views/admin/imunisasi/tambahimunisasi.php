        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Imunisasi</h2>
            </header>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>
            
                            <h2 class="panel-title">Registrasi Anak</h2>
                        </header>
                        <div class="panel-body">
            
                            <form class="form-horizontal form-bordered" action="<?= base_url('admin/prosesTambahImunisasi')?>" method="post">
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Nama Imunisasi</label>
                                    <div class="col-md-6">
                                        <input type="text" name="nama" data-plugin-colorpicker class="colorpicker-default form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Tanggal imunisasi</label>
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                            <input type="text" data-plugin-datepicker name="tglimunisasi" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="col-md-4 control-label">
                                        <button type="submit" class="btn btn-sm btn-primary" data-plugin-colorpicker data-color-format="hex" data-color="rgb(255, 255, 255)">Tambah</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            
            </div>
        </section>
    </div>
</section>
            