        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Jadwal</h2>
            
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a href="index.html">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Edit Jadwal</span></li>
                    </ol>
                </div>
            </header>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                            <h2 class="panel-title">Jam Buka Tutup</h2>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal form-bordered" method="post" action="<?= base_url('admin/prosesUbahJadwal')?>">

                                <div class="form-group">
                                    <div class="col-md-6">
                                        <input type="hidden" name="id" data-plugin-colorpicker class="colorpicker-default form-control" value="<?= $jadwal[0]->id ?>" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">HARI</label>
                                    <div class="col-md-6">
                                        <input type="text" name="hari" readonly data-plugin-colorpicker class="colorpicker-default form-control" value="<?= $jadwal[0]->hari ?>" />
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label">JAM</label>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                    <i class="fa fa-clock-o"></i>
                                                </span>
                                            <input type="text" name="jam1" data-plugin-timepicker class="form-control" data-plugin-options='{ "showMeridian": false }'>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                    <i class="fa fa-clock-o"></i>
                                                </span>
                                            <input type="text" name="jam2" data-plugin-timepicker class="form-control" data-plugin-options='{ "showMeridian": false }'>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-6 col-xs-11">
                                        <button class="btn btn-sm btn-primary" data-plugin-colorpicker data-color-format="hex">Edit Jadwal</button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </section>
                </div>
            </div>

        </section>
    </div>
</section>
            