        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Imunisasi</h2>
            
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a href="index.html">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Imunisasi</span></li>
                    </ol>
                </div>
            </header>

            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <a href="#" class="fa fa-times"></a>
                    </div>
            
                    <h2 class="panel-title">Daftar Imunisasi</h2>
                </header>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="mb-md">
                                <a href="<?= base_url('admin/tambahImunisasi')?>"class="btn btn-primary">Add <i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>    
                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                        <thead>
                            <tr>
                                <th>Id Imunisasi</th>
                                <th>Nama Imunisasi</th>
                                <th>Tanggal Imunisasi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($imunisasi as $i) { ?>
                            
                            <tr class="gradeX">
                                <td><?= $i->id_imunisasi ?></td>
                                <td><?= $i->nama_imunisasi ?></td>
                                <td><?= $i->tanggal_imunisasi ?></td>
                                <td class="center">
                                    <a href="<?= base_url('admin/editImunisasi/').$i->id_imunisasi ?>" class="btn btn-sm btn-success" data-plugin-colorpicker data-color-format="hex" >edit</a>
                                    <a href="<?= base_url('admin/hapusImunisasi/').$i->id_imunisasi ?>" class="btn btn-sm btn-danger" data-plugin-colorpicker data-color-format="hex" >hapus</a>
                                </td>
                            </tr>
                            <?php }?>
                            
                        </tbody>
                    </table>
                </div>
            </section>
            </div>

        </section>
    </div>
</section>
            