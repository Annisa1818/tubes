        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Data Kader</h2>
            
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a href="index.html">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Data Kader</span></li>
                    </ol>
                </div>
            </header>

            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <a href="#" class="fa fa-times"></a>
                    </div>
            
                    <h2 class="panel-title">Data Kader</h2>
                </header>
                <div class="panel-body">
                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                        <thead>
                            <tr>
                                <th>Id Wali</th>
                                <th>Nama Ayah</th>
                                <th>Nama Ibu</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ortu as $i) { ?>
                            
                            <tr class="gradeX">
                                <td><?= $i->id_wali ?></td>
                                <td><?= $i->nama_ibu ?></td>
                                <td><?= $i->nama_ayah ?></td>
                                <td><?= $i->alamat ?></td>
                                <td class="center">
                                    <a href="<?= base_url('admin/tambahAnak/').$i->id_wali ?>" class="btn btn-sm btn-primary" data-plugin-colorpicker data-color-format="hex" data-color="rgb(255, 255, 255)">Registrasi Anak</a>
                                </td>
                            </tr>
                            <?php }?>
                            
                        </tbody>
                    </table>
                </div>
            </section>
            </div>

        </section>
    </div>
</section>
            