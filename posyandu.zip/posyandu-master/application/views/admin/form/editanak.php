<section role="main" class="content-body">
            <header class="page-header">
                <h2>Data Kader</h2>
            </header>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>
            
                            <h2 class="panel-title">Registrasi Anak</h2>
                        </header>
                        <div class="panel-body">
            
                            <form class="form-horizontal form-bordered" action="<?= base_url('admin/prosesEditAnak')?>" method="post">
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <input type="hidden" name="idortu" data-plugin-colorpicker class="colorpicker-default form-control" value="<?= $ortu ?>"/>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <input type="hidden" name="idanak" data-plugin-colorpicker class="colorpicker-default form-control" value="<?= $anak[0]->id_balita ?>"/>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Nama</label>
                                    <div class="col-md-6">
                                        <input type="text" name="nama" data-plugin-colorpicker class="colorpicker-default form-control"  value="<?= $anak[0]->nama ?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Tanggal lahir</label>
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                            <input type="text" data-plugin-datepicker name="tgllahir" class="form-control"  value="<?= $anak[0]->tanggal_lahir ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Umur</label>
                                    <div class="col-md-1">
                                        <input type="number" name="umur" data-plugin-colorpicker class="colorpicker-rgba form-control" data-horizontal="true"  value="<?= $anak[0]->umur ?>"/>
                                    </div>
                                    <label class="col-md-0 control-label">bulan</label>
                                </div>
                                
                                <div class="form-group">
                                    <div class="col-md-4 control-label">
                                        <button type="submit" class="btn btn-sm btn-primary" data-plugin-colorpicker data-color-format="hex">Edit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            
            </div>
        </section>
    </div>
</section>
            