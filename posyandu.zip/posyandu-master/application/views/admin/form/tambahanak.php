<section role="main" class="content-body">
            <header class="page-header">
                <h2>Data Kader</h2>
            </header>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>
            
                            <h2 class="panel-title">Registrasi Anak</h2>
                        </header>
                        <div class="panel-body">
            
                            <form class="form-horizontal form-bordered" action="<?= base_url('admin/prosesRegistrasiAnak')?>" method="post">
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <input type="hidden" name="idortu" data-plugin-colorpicker class="colorpicker-default form-control" value="<?= $id ?>"/>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Nama</label>
                                    <div class="col-md-6">
                                        <input type="text" name="nama" data-plugin-colorpicker class="colorpicker-default form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Tanggal lahir</label>
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                            <input type="text" data-plugin-datepicker name="tgllahir" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Umur</label>
                                    <div class="col-md-1">
                                        <input type="number" name="umur" data-plugin-colorpicker class="colorpicker-rgba form-control" data-horizontal="true"/>
                                    </div>
                                    <label class="col-md-0 control-label">bulan</label>
                                </div>
                                
                                <div class="form-group">
                                    <div class="col-md-4 control-label">
                                        <button type="submit" class="btn btn-sm btn-primary" data-plugin-colorpicker data-color-format="hex" data-color="rgb(255, 255, 255)">Daftar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            
            </div>
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <a href="#" class="fa fa-times"></a>
                    </div>
            
                    <h2 class="panel-title">Daftar Anak</h2>
                </header>
                <div class="panel-body">
                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                        <thead>
                            <tr>
                                <th>Id Anak</th>
                                <th>Nama Anak</th>
                                <th>Umur</th>
                                <th>Tgl lahir</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if(!empty($ortu)){
                            foreach ($ortu as $i) { ?>
                            
                            <tr class="gradeX">
                                <td><?= $i->id_balita ?></td>
                                <td><?= $i->nama ?></td>
                                <td><?= $i->tanggal_lahir ?></td>
                                <td><?= $i->umur ?></td>
                                <td class="center">
                                    <a href="<?= base_url('admin/editAnak/').$i->id_wali."/".$i->id_balita ?>" class="btn btn-sm btn-success" data-plugin-colorpicker data-color-format="hex" >edit</a>
                                    <a href="<?= base_url('admin/hapusAnak/').$i->id_wali."/".$i->id_balita ?>" class="btn btn-sm btn-danger" data-plugin-colorpicker data-color-format="hex" >hapus</a>
                                </td>
                            </tr>
                            <?php }}?>
                            
                        </tbody>
                    </table>
                </div>
            </section>
        </section>
    </div>
</section>
            