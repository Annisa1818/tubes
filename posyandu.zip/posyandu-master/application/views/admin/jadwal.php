<section role="main" class="content-body">
            <header class="page-header">
                <h2>Jadwal</h2>
            
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a href="index.html">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>jadwal</span></li>
                    </ol>
                </div>
            </header>
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>
            
                            <h2 class="panel-title">Actions</h2>
                        </header>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>Hari</th>
                                            <th class="center">Jam</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        foreach ($jadwal as $i) { ?>
                                            <tr>
                                                <th><?= $i->hari ?></th>
                                                <?php if($i->jam == 0){?>
                                                <td class="danger center"> Tutup </td>
                                                <?php }else{ ?>
                                                    <td class="success center"> <?= $i->jam ?> </td>
                                                <?php }?>
                                                
                                                <td>
                                                <a href="<?= base_url('admin/ubahJadwal/').$i->id?>" class="btn btn-sm btn-success" data-plugin-colorpicker data-color-format="hex" >BUKA & EDIT</a>
                                                <a href="<?= base_url('admin/tutupHari/').$i->id ?>" class="btn btn-sm btn-danger" data-plugin-colorpicker data-color-format="hex" >TUTUP</a>
                                                </td>
                                            </tr>     
                                        <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

        </section>
    </div>
</section>
            