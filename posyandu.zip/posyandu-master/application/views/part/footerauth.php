
		<!-- Vendor -->
		<script src="<?= base_url('assets/vendor/jquery/jquery.js')?>"></script>
		<script src="<?= base_url('assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')?>"></script>
		<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.js')?>"></script>
		<script src="<?= base_url('assets/vendor/nanoscroller/nanoscroller.js')?>"></script>
		<script src="<?= base_url('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')?>"></script>
		<script src="<?= base_url('assets/vendor/magnific-popup/magnific-popup.js')?>"></script>
		<script src="<?= base_url('assets/vendor/jquery-placeholder/jquery.placeholder.js')?>"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?= base_url('assets/javascripts/theme.js')?>"></script>
		
		<!-- Theme Custom -->
		<script src="<?= base_url('assets/javascripts/theme.custom.js')?>"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?= base_url('assets/javascripts/theme.init.js')?>"></script>

	</body>
</html>